/*
 * ManderaConnect configuration.
 *
 * DEMO MODE: leave these two values empty. Listings are saved only on this device.
 * SHARED ONLINE MODE: create a free Supabase project, run supabase-schema.sql,
 * then paste your Project URL and anon/publishable key below.
 *
 * Never put a Supabase service_role/secret key in this file.
 */
window.MANDERACONNECT_CONFIG = {
  supabaseUrl: "",
  supabaseAnonKey: ""
};
