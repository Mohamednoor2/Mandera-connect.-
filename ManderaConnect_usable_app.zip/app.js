(() => {
  "use strict";
  const config = window.MANDERACONNECT_CONFIG || {};
  const hasBackend = Boolean(config.supabaseUrl && config.supabaseAnonKey);
  const demoListings = [
    {id:"demo-1",title:"School stationery available",category:"Shops",price:"Prices vary",description:"Exercise books, pens, pencils and other school essentials. Contact for stock and prices.",seller:"Local stationery shop",phone:"254700000001",area:"Mandera Town",created_at:"2026-10-20T09:00:00Z",demo:true},
    {id:"demo-2",title:"Phone repair service",category:"Services",price:"Ask for a quote",description:"Mobile phone troubleshooting and common repairs. Explain the issue before visiting.",seller:"Phone repair technician",phone:"254700000002",area:"Mandera Town",created_at:"2026-10-19T09:00:00Z",demo:true},
    {id:"demo-3",title:"Fresh tea and snacks",category:"Food",price:"From KSh 30",description:"Tea and light snacks. Confirm availability and opening hours directly.",seller:"Local food vendor",phone:"254700000003",area:"Town centre",created_at:"2026-10-18T09:00:00Z",demo:true},
    {id:"demo-4",title:"Looking for casual work?",category:"Jobs",price:"Opportunity notice",description:"A sample listing showing how job opportunities may be posted. Verify every job before sharing documents or paying fees.",seller:"Community notice",phone:"254700000004",area:"Mandera",created_at:"2026-10-17T09:00:00Z",demo:true},
    {id:"demo-5",title:"Tailoring and clothing alterations",category:"Services",price:"Request a quote",description:"Ask about tailoring, repairs, turnaround time and fabric requirements.",seller:"Local tailor",phone:"254700000005",area:"Bula Tawakal",created_at:"2026-10-16T09:00:00Z",demo:true},
    {id:"demo-6",title:"House or room listing",category:"Property",price:"Contact owner",description:"Example property listing. Visit and verify the property, owner and terms before making payment.",seller:"Property contact",phone:"254700000006",area:"Mandera",created_at:"2026-10-15T09:00:00Z",demo:true}
  ];
  const icons = {Shops:"🛍️",Services:"🧰",Jobs:"💼",Property:"🏠",Food:"🍲",Other:"📦"};
  const $ = (id) => document.getElementById(id);
  let listings = [];
  let activeCategory = "All";
  let query = "";
  let supabase = null;
  let installPrompt = null;

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }
  function normalizePhone(phone) {
    let n = String(phone || "").replace(/[^\d+]/g, "");
    if (n.startsWith("+")) n = n.slice(1);
    if (n.startsWith("0") && n.length >= 9) n = "254" + n.slice(1);
    return n;
  }
  function formatDate(value) {
    try { return new Intl.DateTimeFormat("en", {day:"numeric",month:"short"}).format(new Date(value)); }
    catch (_) { return ""; }
  }
  function status(message, error=false) {
    $("notice").textContent = message;
    $("notice").classList.toggle("hidden", !message);
    $("notice").style.background = error ? "#fff0ee" : "";
  }
  function setConnectionState() {
    const el = $("connectionStatus");
    if (hasBackend && supabase) {
      el.innerHTML = '<i></i> Online listings';
      el.classList.add("online");
    } else {
      el.innerHTML = '<i></i> Device-only mode';
      el.classList.remove("online");
    }
  }
  async function initBackend() {
    if (!hasBackend) return;
    try {
      const script = document.createElement("script");
      script.src = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2";
      script.async = true;
      document.head.appendChild(script);
      await new Promise((resolve, reject) => {
        script.onload = resolve; script.onerror = () => reject(new Error("Could not load online database library"));
      });
      supabase = window.supabase.createClient(config.supabaseUrl, config.supabaseAnonKey);
    } catch (err) {
      console.error(err);
      status("Online database could not connect. Check your internet and Supabase settings. Your device-only listings remain available.", true);
    }
  }
  function getLocalListings() {
    try { return JSON.parse(localStorage.getItem("manderaconnect-listings") || "[]"); }
    catch (_) { return []; }
  }
  function saveLocalListing(item) {
    const items = getLocalListings();
    items.unshift(item);
    localStorage.setItem("manderaconnect-listings", JSON.stringify(items));
  }
  async function loadListings() {
    if (hasBackend && supabase) {
      try {
        const {data, error} = await supabase.from("listings").select("*").eq("status","published").order("created_at",{ascending:false}).limit(100);
        if (error) throw error;
        listings = (data || []).concat(getLocalListings());
        setConnectionState();
        renderListings();
        return;
      } catch (err) {
        console.error(err);
        status("Could not load shared listings. Showing example listings and listings saved on this device.", true);
      }
    }
    listings = demoListings.concat(getLocalListings());
    setConnectionState();
    renderListings();
  }
  function filteredListings() {
    const q = query.toLowerCase().trim();
    return listings.filter(item => {
      const categoryOk = activeCategory === "All" || item.category === activeCategory;
      const haystack = [item.title,item.description,item.seller,item.area,item.category].join(" ").toLowerCase();
      return categoryOk && (!q || haystack.includes(q));
    });
  }
  function renderListings() {
    const items = filteredListings();
    $("listingGrid").innerHTML = items.map(item => {
      const category = icons[item.category] ? item.category : "Other";
      return `<article class="listing-card" tabindex="0" role="button" data-id="${escapeHtml(item.id)}" aria-label="View ${escapeHtml(item.title)}">
        <div class="listing-visual cat-${category}"><span>${icons[category] || "📦"}</span><span class="tag">${escapeHtml(category)}</span></div>
        <div class="listing-body"><h3>${escapeHtml(item.title)}</h3><div class="price">${escapeHtml(item.price || "Contact seller")}</div>
        <div class="description">${escapeHtml(item.description)}</div>
        <div class="listing-meta"><div class="seller-info"><span class="seller-dot">${escapeHtml((item.seller || "?").charAt(0).toUpperCase())}</span><span>${escapeHtml(item.seller || "Local seller")}</span></div><span>${escapeHtml(item.area || "Mandera")}</span></div></div>
      </article>`;
    }).join("");
    $("emptyState").classList.toggle("hidden", items.length > 0);
    $("listingGrid").classList.toggle("hidden", items.length === 0);
    $("listingTitle").textContent = activeCategory === "All" ? "Latest listings" : activeCategory;
    $("listingGrid").querySelectorAll(".listing-card").forEach(card => {
      const open = () => showDetail(card.dataset.id);
      card.addEventListener("click", open);
      card.addEventListener("keydown", e => {if (e.key === "Enter" || e.key === " ") {e.preventDefault();open();}});
    });
  }
  function showDetail(id) {
    const item = listings.find(x => String(x.id) === String(id));
    if (!item) return;
    const category = icons[item.category] ? item.category : "Other";
    const phone = normalizePhone(item.phone);
    const whatsapp = phone ? `https://wa.me/${encodeURIComponent(phone)}?text=${encodeURIComponent("Hello, I saw your listing on ManderaConnect: " + item.title)}` : "#";
    $("detailContent").innerHTML = `<span class="eyebrow dark">${escapeHtml(category.toUpperCase())}</span>
      <div class="detail-visual cat-${category}">${icons[category] || "📦"}</div>
      <h2 id="detailTitle">${escapeHtml(item.title)}</h2><div class="price">${escapeHtml(item.price || "Contact seller")}</div>
      <p class="detail-desc">${escapeHtml(item.description)}</p>
      <div class="detail-info"><div><strong>Seller:</strong> ${escapeHtml(item.seller || "Not provided")}</div><div><strong>Area:</strong> ${escapeHtml(item.area || "Mandera")}</div><div><strong>Posted:</strong> ${escapeHtml(formatDate(item.created_at) || "Recently")}</div></div>
      <div class="detail-actions">${phone ? `<a class="btn btn-primary" href="${whatsapp}" target="_blank" rel="noopener">Message on WhatsApp ↗</a><a class="btn btn-light" href="tel:${escapeHtml(phone)}">Call seller</a>` : `<p>Contact details not available.</p>`}</div>
      <p class="safety-note">Safety: confirm the seller, item and final price. Do not send money before you are satisfied that the offer is genuine. Demo listings are examples, not verified businesses.</p>`;
    $("detailModal").classList.remove("hidden");
  }
  function openPost() {
    $("formMessage").textContent = "";
    $("postModal").classList.remove("hidden");
    document.body.style.overflow = "hidden";
    setTimeout(() => $("listingForm").elements.title.focus(), 50);
  }
  function closeModal(id) {
    $(id).classList.add("hidden");
    if ($("postModal").classList.contains("hidden") && $("detailModal").classList.contains("hidden")) document.body.style.overflow = "";
  }
  async function submitListing(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const fd = new FormData(form);
    const item = {
      id: "local-" + Date.now(),
      title: String(fd.get("title") || "").trim(),
      category: String(fd.get("category") || "Other"),
      price: String(fd.get("price") || "").trim(),
      description: String(fd.get("description") || "").trim(),
      seller: String(fd.get("seller") || "").trim(),
      phone: String(fd.get("phone") || "").trim(),
      area: String(fd.get("area") || "Mandera").trim(),
      created_at: new Date().toISOString(),
      status: "published"
    };
    if (!item.title || !item.description || !item.seller || !item.phone) {
      $("formMessage").textContent = "Please complete the required fields.";
      return;
    }
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true; button.textContent = "Publishing…";
    try {
      if (hasBackend && supabase) {
        const {error} = await supabase.from("listings").insert([{
          title:item.title,category:item.category,price:item.price,description:item.description,
          seller:item.seller,phone:item.phone,area:item.area,status:"published"
        }]);
        if (error) throw error;
        status("Your listing was published online and can be seen by other users.");
      } else {
        saveLocalListing(item);
        status("Saved on this device only. To make it visible to everyone, connect the free shared database in the setup guide.");
      }
      form.reset();
      closeModal("postModal");
      await loadListings();
    } catch (err) {
      console.error(err);
      $("formMessage").textContent = "Could not publish online. Check the connection and database setup, then try again.";
    } finally {
      button.disabled = false; button.textContent = "Publish listing";
    }
  }
  document.querySelectorAll(".category").forEach(btn => btn.addEventListener("click", () => {
    activeCategory = btn.dataset.category;
    document.querySelectorAll(".category").forEach(b => b.classList.toggle("active", b === btn));
    renderListings();
  }));
  $("searchBtn").addEventListener("click", () => {query = $("searchInput").value;renderListings();});
  $("searchInput").addEventListener("input", () => {query = $("searchInput").value;renderListings();});
  $("openPostBtn").addEventListener("click", openPost);
  $("closePostBtn").addEventListener("click", () => closeModal("postModal"));
  $("closeDetailBtn").addEventListener("click", () => closeModal("detailModal"));
  $("postModal").addEventListener("click", e => {if (e.target.dataset.close) closeModal("postModal");});
  $("detailModal").addEventListener("click", e => {if (e.target.dataset.detailClose) closeModal("detailModal");});
  $("listingForm").addEventListener("submit", submitListing);
  document.addEventListener("keydown", e => {if(e.key === "Escape"){closeModal("postModal");closeModal("detailModal");}});
  window.addEventListener("beforeinstallprompt", event => {
    event.preventDefault(); installPrompt = event; $("installBtn").classList.remove("hidden");
  });
  $("installBtn").addEventListener("click", async () => {
    if (!installPrompt) return;
    installPrompt.prompt(); await installPrompt.userChoice; installPrompt = null; $("installBtn").classList.add("hidden");
  });
  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
    window.addEventListener("load", () => navigator.serviceWorker.register("./service-worker.js").catch(console.warn));
  }
  (async () => {await initBackend(); await loadListings();})();
})();